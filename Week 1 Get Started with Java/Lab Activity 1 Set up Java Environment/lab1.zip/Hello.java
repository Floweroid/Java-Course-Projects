/**
* Hello and welcome program.
*
* @author Zekai Lin
* @version 31/08/2022
*/
    public class Hello {
        public static void main(String[] args) {
            String message, message2;
            message ="Welcome to CIS 351!\n";
            message2 = "I'm happy to be a programmer.";
            System.out.print(message+message2);
            }
}
